﻿#include "MathLib_SIMD/include/Vec3_SIMD.h"
#include "MathLib_SIMD/include/Vec3_ASM.h"

#include <algorithm>
#include <limits>

namespace MathsSIMD
{
#pragma region Initialize

    
    Vec3_SIMD::Vec3_SIMD() : data(_mm_setzero_ps())
    {
    }

    Vec3_SIMD::Vec3_SIMD(float x, float y, float z) noexcept
        : data(_mm_setr_ps(x, y, z, 0.f))
    {
    }

    Vec3_SIMD::Vec3_SIMD(const __m128& vec) : data(vec)
    {
    }
    
#pragma endregion

    __m128 Vec3_SIMD::Load(const Vec3& vecToSimd) const
    {
        return _mm_setr_ps(vecToSimd.x, vecToSimd.y, vecToSimd.z,0.f);
    }
    
    Vec3 Vec3_SIMD::Store(__m128 simdToVec) const
    {
        float components[4];
        _mm_storeu_ps(components, simdToVec);

        return {
            components[0],
            components[1],
            components[2],
        };
    }



#pragma region Operators 

    Vec3_SIMD Vec3_SIMD::operator+(const Vec3_SIMD& rhs) const
    {
        const __m128 vecA = this->data;
        const __m128 vecB = rhs.data;
        
        const __m128 result = _mm_add_ps (vecA, vecB);
        
        return Vec3_SIMD(result);
    }
    
    Vec3_SIMD Vec3_SIMD::operator-(const Vec3_SIMD& rhs) const
    {
        const __m128 vecA = this->data;
        const __m128 vecB = rhs.data;
        
        const __m128 result = _mm_sub_ps (vecA, vecB);
        
        return Vec3_SIMD(result);
    }
    
    Vec3_SIMD Vec3_SIMD::operator*(const Vec3_SIMD& rhs) const
    {
        const __m128 vecA = this->data;
        const __m128 vecB = rhs.data;
        
        const __m128 result = _mm_mul_ps (vecA, vecB);
        
        return Vec3_SIMD(result);
    }
    
    Vec3_SIMD Vec3_SIMD::operator/(const Vec3_SIMD& rhs) const
    {
        const float x = _mm_cvtss_f32(rhs.data);
        const float y = _mm_cvtss_f32(_mm_shuffle_ps(rhs.data, rhs.data, _MM_SHUFFLE(1, 1, 1, 1)));
        const float z = _mm_cvtss_f32( _mm_shuffle_ps(rhs.data, rhs.data, _MM_SHUFFLE(2, 2, 2, 2)));
        
        if (x == 0.0f ||
            y == 0.0f ||
            z == 0.0f)
        {
            throw std::runtime_error("Division by zero");
        }
        
        const __m128 vecA = this->data;
        const __m128 vecB = rhs.data;
        
        const __m128 result = _mm_div_ps (vecA, vecB);
        
        return Vec3_SIMD(result);
    }

    Vec3_SIMD Vec3_SIMD::operator-() const
    {
        const Vec3 nullVec { 0.f,0.f,0.f };
        const __m128 nullRegister = Load(nullVec);
        const __m128 vecA = this->data;
        
        const __m128 minusVecA = _mm_sub_ps (nullRegister, vecA);
        
        return Vec3_SIMD(minusVecA);
    }

    Vec3_SIMD Vec3_SIMD::operator*(float scalar) const
    {
        const __m128 vecA = this->data;
        const __m128 vScalar = _mm_set1_ps(scalar);
        
        const __m128 result = _mm_mul_ps (vecA, vScalar);
        
        return Vec3_SIMD(result);
    }
    
    Vec3_SIMD Vec3_SIMD::operator/(float scalar) const
    {
        if (scalar == 0.0f)
        {
            throw std::runtime_error("Division by zero");
        }
        
        const __m128 vecA = this->data;
        const __m128 vScalar = _mm_set1_ps(scalar);
        
        const __m128 result = _mm_div_ps (vecA, vScalar);
        
        return Vec3_SIMD(result);
    }

    Vec3_SIMD& Vec3_SIMD::operator+=(const Vec3_SIMD& rhs)
    {
         __m128 vecA = this->data;
        const __m128 vecB = rhs.data;
        
        vecA = _mm_add_ps (vecA, vecB);
        this->data = vecA;
        
        return *this;
    }
    
    Vec3_SIMD& Vec3_SIMD::operator-=(const Vec3_SIMD& rhs)
    {
        __m128 vecA = this->data;
        const __m128 vecB = rhs.data;
        
        vecA = _mm_sub_ps (vecA, vecB);
        this->data = vecA;
        
        return *this;
    }
    
    Vec3_SIMD& Vec3_SIMD::operator*=(const Vec3_SIMD& rhs)
    {
        __m128 vecA = this->data;
        __m128 vecB = rhs.data;
        
        vecA = _mm_mul_ps (vecA, vecB);
        this->data = vecA;
        
        return *this;
    }
    
    Vec3_SIMD& Vec3_SIMD::operator/=(const Vec3_SIMD& rhs)
    {
        const float x = _mm_cvtss_f32(rhs.data);
        const float y = _mm_cvtss_f32(_mm_shuffle_ps(rhs.data, rhs.data, _MM_SHUFFLE(1, 1, 1, 1)));
        const float z = _mm_cvtss_f32(_mm_shuffle_ps(rhs.data, rhs.data, _MM_SHUFFLE(2, 2, 2, 2)));

        if (x == 0.0f || y == 0.0f || z == 0.0f)
        {
            throw std::runtime_error("Division by zero");
        }
        
        __m128 vecA = this->data;
        const __m128 vecB = rhs.data;
        
        vecA = _mm_div_ps (vecA, vecB);
        this->data = vecA;
        
        return *this;
    }

    Vec3_SIMD& Vec3_SIMD::operator*=(float scalar)
    {
        __m128 vecA = this->data;
        __m128 vScalar = _mm_set1_ps(scalar);
        
        vecA = _mm_mul_ps (vecA, vScalar);
        this->data = vecA;
        
        return *this;
    }
    
    Vec3_SIMD& Vec3_SIMD::operator/=(float scalar)
    {
        if (scalar == 0.0f)
        {
            throw std::runtime_error("Division by zero");
        }
        __m128 vecA = this->data;
        __m128 vScalar = _mm_set1_ps(scalar);
        
        vecA = _mm_div_ps (vecA, vScalar);
        this->data = vecA;
        
        return *this;
    }

    bool Vec3_SIMD::operator==(const Vec3_SIMD& rhs) const
    {
        const __m128 vecA = this->data;
        const __m128 vecB = rhs.data;
        
        const __m128 result = _mm_cmpeq_ps(vecA, vecB);
        return _mm_movemask_ps(result) == 0xF;
    }
    
    bool Vec3_SIMD::operator!=(const Vec3_SIMD& rhs) const
    {
        const __m128 result = _mm_cmpneq_ps(data, rhs.data);
        return _mm_movemask_ps(result) != 0;
    }


#pragma endregion
    
#pragma region MathFormula 
    float Vec3_SIMD::Dot(const Vec3_SIMD& rhs) const
    {
        const __m128 vecA = this->data;
        const __m128 vecB = rhs.data;
        
        const __m128 result = _mm_mul_ps (vecA, vecB);
        
        float x = _mm_cvtss_f32(result);
        float y = _mm_cvtss_f32(_mm_shuffle_ps(result, result, _MM_SHUFFLE(1, 1, 1, 1)));
        float z = _mm_cvtss_f32(_mm_shuffle_ps(result, result, _MM_SHUFFLE(2, 2, 2, 2)));
        
        return x + y + z;
    }

Vec3_SIMD Vec3_SIMD::Cross(const Vec3_SIMD& rhs) const
{
    const __m128 vecA = this->data;
    const __m128 vecB = rhs.data;

    const __m128 vecA_yzx = _mm_shuffle_ps(vecA, vecA, _MM_SHUFFLE(3, 0, 2, 1));
    const __m128 vecB_zxy = _mm_shuffle_ps(vecB, vecB, _MM_SHUFFLE(3, 1, 0, 2));

    const __m128 result1 = _mm_mul_ps(vecA_yzx, vecB_zxy);

    const __m128 vecA_zxy = _mm_shuffle_ps(vecA, vecA, _MM_SHUFFLE(3, 1, 0, 2));
    const __m128 vecB_yzx = _mm_shuffle_ps(vecB, vecB, _MM_SHUFFLE(3, 0, 2, 1));

    const __m128 result2 = _mm_mul_ps(vecA_zxy, vecB_yzx);

    const __m128 resultCross = _mm_sub_ps(result1, result2);

    return Vec3_SIMD(resultCross);
}

    float Vec3_SIMD::MagnitudeSquared() const
    {
        return Dot(*this);
    }
    
    float Vec3_SIMD::Magnitude() const
    {
        const __m128 vecA = this->data;
        
        const __m128 squared = _mm_mul_ps(vecA, vecA);
        
        // only y²
        const __m128 y_squared = _mm_shuffle_ps(squared, squared, _MM_SHUFFLE(1, 1, 1, 1));
        // only z²
        const __m128 z_squared = _mm_shuffle_ps(squared, squared, _MM_SHUFFLE(2, 2, 2, 2));
        
        // x² + y²
        const __m128 result1 = _mm_add_ps(squared, y_squared);
        
        // (x² + y²) + z²
        const __m128 magnitudeSquared  = _mm_add_ps(result1, z_squared);
        
        // square root
        const __m128 magnitude = _mm_sqrt_ps(magnitudeSquared);
        
        // return first value
        return _mm_cvtss_f32(magnitude);
    }

    Vec3_SIMD Vec3_SIMD::Normalize() const
    {
        const float x = _mm_cvtss_f32(data);
        const float y = _mm_cvtss_f32(_mm_shuffle_ps(data, data, _MM_SHUFFLE(1, 1, 1, 1)));
        const float z = _mm_cvtss_f32( _mm_shuffle_ps(data, data, _MM_SHUFFLE(2, 2, 2, 2)));
        
        if (!std::isfinite(x) || !std::isfinite(y) || !std::isfinite(z))
        {
            throw std::domain_error("Cannot normalize non-finite components");
        }
        
        const float magnitude = Magnitude();
        
        if (magnitude == 0.0f || !std::isfinite(magnitude))
        {
            throw std::domain_error("Cannot divide by zero or magnitude infinite");
        }
        
        const __m128 vecA = this->data;
        const __m128 MagnitudeV = _mm_set1_ps(magnitude);
        
        const __m128 resultNormalize = _mm_div_ps (vecA, MagnitudeV);
        
        return Vec3_SIMD(resultNormalize);
    }

    float Vec3_SIMD::DistanceSquared(const Vec3_SIMD& rhs) const
    {
        const __m128 vecA = this->data;
        const __m128 vecB = rhs.data;
        
        const __m128 diff = _mm_sub_ps (vecA, vecB);
        const __m128 squaredDiff = _mm_mul_ps (diff, diff);
        
        // only y²
        const __m128 squaredDiff_y = _mm_shuffle_ps(squaredDiff, squaredDiff, _MM_SHUFFLE(1, 1, 1, 1));
        // only z²
        const __m128 squaredDiff_z = _mm_shuffle_ps(squaredDiff, squaredDiff, _MM_SHUFFLE(2, 2, 2, 2));
        
        // x² + y²
        const __m128 squaredDiff_withY = _mm_add_ps(squaredDiff, squaredDiff_y);
        
        // (x² + y²) + z²
        const __m128 result = _mm_add_ps(squaredDiff_withY, squaredDiff_z);
        
        return _mm_cvtss_f32(result);
    }
    
    float Vec3_SIMD::Distance(const Vec3_SIMD& rhs) const
    {
        const __m128 vecA = this->data;
        const __m128 vecB = rhs.data;
        
        const __m128 diff = _mm_sub_ps (vecA, vecB);
        const __m128 squaredDiff = _mm_mul_ps (diff, diff);
        
        // only y²
        const __m128 squaredDiff_y = _mm_shuffle_ps(squaredDiff, squaredDiff, _MM_SHUFFLE(1, 1, 1, 1));
        // only z²
        const __m128 squaredDiff_z = _mm_shuffle_ps(squaredDiff, squaredDiff, _MM_SHUFFLE(2, 2, 2, 2));
        
        // x² + y²
        const __m128 squaredDiff_withY = _mm_add_ps(squaredDiff, squaredDiff_y);
        
        // (x² + y²) + z²
        const __m128 squaredDiff_withZ = _mm_add_ps(squaredDiff_withY, squaredDiff_z);
        
        const __m128 result = _mm_sqrt_ps(squaredDiff_withZ);
        
        return _mm_cvtss_f32(result);
    }

    float Vec3_SIMD::Angle(const Vec3_SIMD& rhs) const
    {
        const Vec3_SIMD normalizedA = Normalize();
        const Vec3_SIMD normalizedB = rhs.Normalize();

        const float cosine = normalizedA.Dot(normalizedB);

        if (!std::isfinite(cosine))
        {
            throw std::domain_error("Cannot calculate angle with non-finite cosine");
        }

        const float clampedCosine = std::clamp(cosine, -1.0f, 1.0f);

        return std::acos(clampedCosine);
    }

    Vec3_SIMD Vec3_SIMD::Lerp(const Vec3_SIMD& a, const Vec3_SIMD& b, float t)
    {
        const __m128 vecA = a.data;
        const __m128 vecB = b.data;
        
        
        const __m128 scalar = _mm_set1_ps(t);
        const __m128 oneMinusT = _mm_sub_ps(_mm_set1_ps(1.0f), scalar);
        
        const __m128 resultA = _mm_mul_ps (vecA, oneMinusT);
        const __m128 resultB = _mm_mul_ps (vecB, scalar);
        
        const __m128 resultLerp = _mm_add_ps (resultA, resultB);
        
        return Vec3_SIMD(resultLerp);
    }

    Vec3_SIMD Vec3_SIMD::Min(const Vec3_SIMD& a, const Vec3_SIMD& b)
    {
        const __m128 vecA = a.data;
        const __m128 vecB = b.data;
        
        const __m128 minVec = _mm_min_ps(vecA, vecB);
        return Vec3_SIMD(minVec);
    }

    Vec3_SIMD Vec3_SIMD::Max(const Vec3_SIMD& a, const Vec3_SIMD& b)
    {
        const __m128 vecA = a.data;
        const __m128 vecB = b.data;
        
        const __m128 maxVec = _mm_max_ps(vecA, vecB);
        return Vec3_SIMD(maxVec); 
    }

    const Vec3_SIMD Vec3_SIMD::Zero{0,0,0};
    
    
    const Vec3_SIMD Vec3_SIMD::One{1, 1, 1};
    
    
    const Vec3_SIMD Vec3_SIMD::UnitX{1, 0, 0};
    
    
    const Vec3_SIMD Vec3_SIMD::UnitY{0, 1, 0};
    
    
    const Vec3_SIMD Vec3_SIMD::UnitZ{0, 0, 1};


    float Vec3_SIMD::DotASM(const Vec3_SIMD& rhs) const
    {
        return DotVec3ASM(reinterpret_cast<const float*>(&data),reinterpret_cast<const float*>(&rhs.data));
    }
#pragma endregion
    
}
